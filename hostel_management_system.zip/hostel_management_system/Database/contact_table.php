<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// $sql = "CREATE TABLE contact_form (
//      name VARCHAR(50) NOT NULL,
//      Email VARCHAR(50) NOT NULL,
//      message VARCHAR(50) NOT NULL
// )";

$name = $mail = $message = "";
  
if(isset($_POST['name'])){                    
    $name = $_POST['name'];
  }
  else{
    $name = "name not set in GET Method.";
}; 

if(isset($_POST['mail'])){                    
    $mail = $_POST['mail'];
  }
  else{
    $mail = "mail not set in GET Method.";
}

if(isset($_POST['message'])){                    
    $message = $_POST['message'];
  }
  else{
    $message = "message not set in GET Method.";
}

$sql= "INSERT INTO contact_form VALUES ('$name','$mail','$message')";

if ($conn->query($sql) === TRUE) {
    echo "Contact info inserted successfully";
} else {
    echo "Error creating table: " . $conn->error;
}
  
$conn->close();
?>