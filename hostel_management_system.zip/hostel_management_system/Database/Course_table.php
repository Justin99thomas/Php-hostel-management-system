<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
// $sql = "CREATE TABLE Course(course_id int PRIMARY KEY,course_name varchar(50) NOT NULL,no_of_year int NOT NULL,status_ varchar(50))";

$course = $date = $status = "";

if(isset($_POST['course'])){                       
  $course = $_POST['course'];
}
else{
  $course = "course name not set in GET Method.";
}
if(isset($_POST['date'])){                    
  $date = $_POST['date'];
}
else{
  $date = "date not set in GET Method.";
}

if(isset($_POST['status'])){                       
  $status = $_POST['status'];
}
else{
  $status = "status not set in GET Method.";
}

$sql = "INSERT INTO Course(course_name, no_of_year, status_) 
VALUES ('$course','$date','$status')";

if ($conn->query($sql) === TRUE) {
  echo "Course inserted successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>