<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE Visitor(visitor_id int primary key, st_id int, name varchar(50), type varchar(50), username varchar(50), password
varchar(50), contact int, comments varchar(50), status varchar(50), FOREIGN KEY (st_id) REFERENCES Student(st_id) )";

if ($conn->query($sql) === TRUE) {
  echo "Table Student created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>