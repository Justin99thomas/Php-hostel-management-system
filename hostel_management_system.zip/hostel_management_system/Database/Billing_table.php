<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE Billing(bill_id int primary key, reg_id int, bill_type varchar(20), paid_amt int, paid_date date, 
FOREIGN KEY (reg_id) REFERENCES Registration(reg_id) )";

if ($conn->query($sql) === TRUE) {
  echo "Table Student created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>