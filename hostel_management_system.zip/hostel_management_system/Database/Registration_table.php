<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// // sql to create table
// $sql = "CREATE TABLE Registration(Reg_id int PRIMARY KEY,st_id int,Room_id int,stud_type varchar(50),startdate date,enddate date,food_type
// varchar(50),beverage_type varchar(50),status_ varchar(50), FOREIGN KEY (st_id) REFERENCES Student(st_id))";

$stud_type = $startdate = $enddate = $food_type = $beverage = "";

if(isset($_POST['studtype'])){                       
  $stud_type = $_POST['studtype'];
}
else{
  $stud_type = "studtype not set in GET Method.";
}

if(isset($_POST['join-date'])){                    
  $startdate = $_POST['join-date'];
}
else{
  $startdate = "join-date not set in GET Method.";
}

if(isset($_POST['end-date'])){                       
  $enddate = $_POST['end-date'];
}
else{
  $enddate = "end-date not set in GET Method.";
}

if(isset($_POST['food'])){                       
  $food_type = $_POST['food'];
}
else{
  $food_type = "food not set in GET Method.";
}

if(isset($_POST['beverage'])){                       
  $beverage = $_POST['beverage'];
}
else{
  $beverage = "beverage Name not set in GET Method.";
}

$sql = "INSERT INTO Registration(stud_type, startdate, enddate, food_type, beverage_type) 
VALUES ('$stud_type','$startdate','$enddate','$food_type','$beverage')";

if ($conn->query($sql) === TRUE) {
  echo "Registration inserted successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>