<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE Employee(emp_id int PRIMARY KEY,block_id int,login_id int, password varchar(50),emp_type varchar(50), emp_name varchar(50), gender
varchar(20),DOB date,DOJ date, FOREIGN KEY (block_id) REFERENCES Blocks(block_id))";

if ($conn->query($sql) === TRUE) {
  echo "Table Registration created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>