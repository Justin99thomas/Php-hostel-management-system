<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE Block_Allotment(allotment_id int primary key, block_id int, course_id int, status varchar(50), 
FOREIGN KEY (block_id) REFERENCES Blocks(block_id), FOREIGN KEY (course_id) REFERENCES Course(course_id) )";

if ($conn->query($sql) === TRUE) {
  echo "Table Student created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>