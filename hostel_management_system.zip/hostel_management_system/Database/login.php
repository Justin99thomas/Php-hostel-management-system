<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$username = $password = "";

if(isset($_POST['student_name'])){                       
  $username = $_POST['student_name'];
}
else{
  $username = "full name not set in GET Method.";
}

if(isset($_POST['pwd'])){                    
  $password = $_POST['pwd'];
}
else{
  $password = "password not set in GET Method.";
}

$sql = "INSERT INTO login(username, password) 
VALUES ('$username','$password')";

if ($conn->query($sql) === TRUE) {
  echo "login info inserted successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>