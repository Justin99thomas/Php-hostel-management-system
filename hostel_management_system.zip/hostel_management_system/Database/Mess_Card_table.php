<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// // sql to create table
// $sql = "CREATE TABLE Mess_Card(messcard_id int primary key, reg_id int, messcard_type varchar(50), startdate date, enddate date,
// status varchar(50), FOREIGN KEY (reg_id) REFERENCES Registration(reg_id) )";

$messcard = $startdate = $enddate = $status = "";

if(isset($_POST['messcardtype'])){                       
  $messcard = $_POST['messcardtype'];
}
else{
  $messcard = "messcard not set in GET Method.";
}
if(isset($_POST['start-date'])){                       
  $startdate = $_POST['start-date'];
}
else{
  $startdate = "startdate not set in GET Method.";
}
if(isset($_POST['end-date'])){                       
  $enddate = $_POST['end-date'];
}
else{
  $enddate = "enddate not set in GET Method.";
}
if(isset($_POST['status'])){                       
  $status = $_POST['status'];
}
else{
  $status = "status not set in GET Method.";
}

$sql = "INSERT INTO Mess_Card(messcard_type, startdate, enddate, status) 
VALUES ('$messcard','$startdate','$enddate','$status')";

if ($conn->query($sql) === TRUE) {
  echo "messcard inserted successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>