<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
// $sql = "CREATE TABLE Student(St_id int primary key, course_id int, name varchar(50), roll_no int, DOB date, Father_name varchar(50), Mother_name
// varchar(50), gender varchar(50), contact int, parent_no int, blood_group varchar(10), status varchar(50), 
// FOREIGN KEY (course_id) REFERENCES Course(course_id) )";

$course_id = $name = $roll_no = $DOB = $Father_name = $Mother_name = $gender = $contact = $parent_no = 
$blood_group = $status = "";

if(isset($_POST['courses'])){                       
  $course_id = $_POST['courses'];
}
else{
  $course_id = "course not set in GET Method.";
}

if(isset($_POST['name'])){                    
  $name = $_POST['name'];
}
else{
  $name = "name not set in GET Method.";
}

if(isset($_POST['rollno'])){                       
  $roll_no = $_POST['rollno'];
}
else{
  $roll_no = "rollno not set in GET Method.";
}

if(isset($_POST['DOB'])){                       
  $DOB = $_POST['DOB'];
}
else{
  $DOB = "dob not set in GET Method.";
}

if(isset($_POST['fname'])){                       
  $Father_name = $_POST['fname'];
}
else{
  $Father_name = "father Name not set in GET Method.";
}

if(isset($_POST['mname'])){                       
  $Mother_name = $_POST['mname'];
}
else{
  $Mother_name = "mother Name not set in GET Method.";
}

$gender = $_POST['gender'];
if (isset($_POST['gender']) && $_POST['gender'] == 'Male') {
  // male radio button was selected
} else if (isset($_POST['gender']) && $_POST['gender'] == 'Female') {
  // female radio button was selected
} else {
  // no radio button was selected
}
              


if(isset($_POST['umobile'])){                       
  $contact = $_POST['umobile'];
}
else{
  $contact = "contact not set in GET Method.";
}

if(isset($_POST['pmobile'])){                       
  $parent_no = $_POST['pmobile'];
}
else{
  $parent_no = "parent no. not set in GET Method.";
}

if(isset($_POST['bloodgroup'])){                       
  $blood_group = $_POST['bloodgroup'];
}
else{
  $blood_group = "bloodgroup not set in GET Method.";
}

if(isset($_POST['status'])){                       
  $status = $_POST['status'];
}
else{
  $status = "status not set in GET Method.";
}

$sql = "INSERT INTO Student(course_id, name, roll_no, DOB, Father_name, Mother_name, gender, 
contact, parent_no, blood_group, status) VALUES ('$course_id','$name','$roll_no','$DOB','$Father_name',
'$Mother_name','$gender','$contact','$parent_no','$blood_group','$status')";

if ($conn->query($sql) === TRUE) {
  echo "<a href='student_details.php'></a>";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>