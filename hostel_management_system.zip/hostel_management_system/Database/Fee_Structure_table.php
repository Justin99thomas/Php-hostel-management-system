<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE Fee_Structure(fee_str_id int primary key, course_id int, fee_type varchar(50), cost int, 
FOREIGN KEY (course_id) REFERENCES Course(course_id) )";

if ($conn->query($sql) === TRUE) {
  echo "Table Student created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>