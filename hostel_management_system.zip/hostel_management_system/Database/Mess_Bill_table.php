<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE Mess_Bill(messbill_id int primary key, reg_id int, fee_str_id int, currentdate date, messbill int,status varchar(50), 
FOREIGN KEY (reg_id) REFERENCES Registration(reg_id), FOREIGN KEY (fee_str_id) REFERENCES Fee_Structure(fee_str_id) )";

if ($conn->query($sql) === TRUE) {
  echo "Table Student created successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>