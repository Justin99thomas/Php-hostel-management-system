<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "hostel_management_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// // sql to create table
// $sql = "CREATE TABLE Blocks(block_id int primary key, block_name varchar(50), gender varchar(10), description varchar(50), status varchar
// (50) )";

$name = $gender = $description = $status = "";

if(isset($_POST['name'])){                       
  $name = $_POST['name'];
}
else{
  $name = "name not set in GET Method.";
}

$gender = $_POST['gender'];
if (isset($_POST['gender']) && $_POST['gender'] == 'Male') {
  // male radio button was selected
} else if (isset($_POST['gender']) && $_POST['gender'] == 'Female') {
  // female radio button was selected
} else {
  // no radio button was selected
}

if(isset($_POST['address'])){                    
  $description = $_POST['address'];
}
else{
  $description = "description not set in GET Method.";
}

if(isset($_POST['status'])){                       
  $status = $_POST['status'];
}
else{
  $status = "status not set in GET Method.";
}

$sql = "INSERT INTO Blocks(block_name, gender, description, status) 
VALUES ('$name','$gender','$description','$status')";

if ($conn->query($sql) === TRUE) {
  echo "Blocks value inserted successfully";
} else {
  echo "Error creating table: " . $conn->error;
}

$conn->close();
?>