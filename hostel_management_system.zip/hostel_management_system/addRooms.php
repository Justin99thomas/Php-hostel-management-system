<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add rooms Table Form</title>
</head>

<body>
    <h1 align="center">Add rooms</h1>

    <table align="center" border="1" cellpadding="10"
        style="background-size:100% 100%;color:black;font-family:arial;background:#d1e2e6">
        <caption>Add rooms</caption>

        <tr>
            <td>Block</td>
            <td>
                <input list="block" placeholder="select" required>
                <datalist id="block">
                    <option value="block-A">
                    <option value="block-B">
                </datalist>
            </td>
        </tr>
        <tr>
            <td>Room no</td>
            <td><input type="text" name="room-no" placeholder="room no."></td>
        </tr>
        <tr>
            <td>No of beds</td>
            <td><input type="number" placeholder="No of beds" min="0" max="50" size="30"></td>
        </tr>
        <tr>
            <td>Description</td>
            <td><textarea name="address" placeholder="TEST BLOCK" cols="30" rows="3"></textarea></td>
        </tr>
        <tr>
            <td>Status</td>
            <td>
                <input list="studenttype" placeholder="select" required>
                <datalist id="studenttype">
                    <option value="Enabled">
                    <option value="Disabled">
                </datalist>
            </td>
        </tr>

        <tr>
            <td colspan="2" align="center"><input type="submit"></td>
        </tr>

    </table>
</body>

</html>