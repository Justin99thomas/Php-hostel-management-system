<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visitor Table Form</title>
</head>
<body>
    <h1 align="center">VISITOR LOG-IN</h1>

    <table align="center" border="1"  cellpadding="15" style="background-size:100% 100%;color:black;font-family:arial;background:#d1e2e6">
        <caption>Please Enter your username and password</caption>

        <tr>
            <td>User Name</td>
            <td><input type="text" name="username" autofocus maxlength="10" placeholder="Enter username" required size="30"></td>
        </tr>
        <tr>
            <td>Password</td>
            <td><input type="password" name="password" autofocus maxlength="10" placeholder="Enter password" required size="30"></td>
        </tr>
        <tr>
            <td colspan="2" align="center"><input type="submit"></td>
        </tr>

    </table>
</body>
</html>