<?php
  require '../includes/config.inc.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title> Allocated Rooms</title>

	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<meta name="keywords" content="Intrend Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);
		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!--bootsrap -->

	<!--// Meta tag Keywords -->

	<!-- css files -->
	<link rel="stylesheet" href="../web_home/css_home/bootstrap.css"> <!-- Bootstrap-Core-CSS -->
	<link rel="stylesheet" href="../web_home/css_home/style.css" type="text/css" media="all" /> <!-- Style-CSS -->
	<link rel="stylesheet" href="../web_home/css_home/fontawesome-all.css"> <!-- Font-Awesome-Icons-CSS -->
	<!-- //css files -->

	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Poiret+One&amp;subset=cyrillic,latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
	<!-- //web-fonts -->

</head>

<body>

<!-- banner -->
<div class="inner-page-banner" id="home">
	<!--Header-->
	<header>
		<div class="container agile-banner_nav">
			<nav class="navbar navbar-expand-lg navbar-light bg-light">

				<h1><a class="navbar-brand" href="admin_home.php">HMS <span class="display"> </span></a></h1>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>

				<div class="collapse navbar-collapse justify-content-center" id="navbarSupportedContent">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item active">
							<a class="nav-link" href="admin_home.php">Home <span class="sr-only">(current)</span></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="create_hm.php">Appoint Hostel Manager</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="students.php">Students</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="admin_contact.php">Contact</a>
						</li>
			            <li class="dropdown nav-item">
						<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
							<b class="caret"></b>
						</a>
						<ul class="dropdown-menu agile_short_dropdown">
							<li>
								<a href="admin_profile.php">My Profile</a>
							</li>
							<li>
								<a href="../includes/logout.inc.php">Logout</a>
							</li>
						</ul>
					</li>
					
					</ul>
				</div>
			</nav>
		</div>
	</header>
	<!--Header-->
</div>
<!-- //banner -->
<div class="container">
	<h2 class="heading text-capitalize mb-sm-5 mb-4"> Student Details </h2>						
					<?php
						// Connect to MySQL database
						$servername = "localhost";
						$username = "root";
						$password = "";
						$database = "hostel_management_system";

						// Create connection
						$conn = new mysqli($servername, $username, $password, $database);
						// Check connection
						if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
						}

						// Get data from users table
						$sql = "SELECT * FROM student";
						$result = mysqli_query($conn, $sql);

						// Display data in a table
						echo "<table border=2>";
						echo "<tr><th>Course_ID</th><th>Name</th><th>Roll_no</th><th>DOB</th><th>Father Name</th>
						<th>Mother Name</th><th>Gender</th><th>Contact</th><th>Parent no.</th><th>Blood group</th>
						<th>Status</th><th>Action</th></tr>";
						while ($row = mysqli_fetch_assoc($result)) {
							//course_id int, name varchar(50), roll_no int, DOB date, Father_name varchar(50), Mother_name
						// varchar(50), gender varchar(50), contact int, parent_no int, blood_group varchar(10), status varchar(50),
							echo "<tr>";
							echo "<td>" . $row["course_id"] . "</td>";
							echo "<td>" . $row["name"] . "</td>";
							echo "<td>" . $row["roll_no"] . "</td>";
							echo "<td>" . $row["DOB"] . "</td>";
							echo "<td>" . $row["Father_name"] . "</td>";
							echo "<td>" . $row["Mother_name"] . "</td>";
							echo "<td>" . $row["gender"] . "</td>";
							echo "<td>" . $row["contact"] . "</td>";
							echo "<td>" . $row["parent_no"] . "</td>";
							echo "<td>" . $row["blood_group"] . "</td>";
							echo "<td>" . $row["status"] . "</td>";
							echo "<td><a href='../student_details.php?id=" . $row["course_id"] . "'>Edit</a> | <a href='../student_details.php?id=" . $row["course_id"] . "'>Delete</a></td>";
							echo "</tr>";
						}
						echo "</table>";

						// Close MySQL connection
						mysqli_close($conn);

						?>

</div>
<div class="container">
	<h2 class="heading text-capitalize mb-sm-5 mb-4"> Registration Details </h2>						
					<?php
						// Connect to MySQL database
						$servername = "localhost";
						$username = "root";
						$password = "";
						$database = "hostel_management_system";

						// Create connection
						$conn = new mysqli($servername, $username, $password, $database);
						// Check connection
						if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
						}

						// Get data from users table
						$sql = "SELECT * FROM Registration";
						$result = mysqli_query($conn, $sql);

						// Display data in a table
						echo "<table border=2>";
						echo "<tr><th>Reg_ID</th><th>Stud_Type</th><th>Start date</th><th>End date</th><th>Food type</th>
						<th>Beverage type</th><th>Status</th><th>Action</th></tr>";
						while ($row = mysqli_fetch_assoc($result)) {
							//Reg_id int PRIMARY KEY,st_id int,Room_id int,stud_type varchar(50),startdate date,enddate date,food_type
// varchar(50),beverage_type varchar(50),status_ varchar(50)
							echo "<tr>";
							echo "<td>" . $row["Reg_id"] . "</td>";
							echo "<td>" . $row["stud_type"] . "</td>";
							echo "<td>" . $row["startdate"] . "</td>";
							echo "<td>" . $row["enddate"] . "</td>";
							echo "<td>" . $row["food_type"] . "</td>";
							echo "<td>" . $row["beverage_type"] . "</td>";
							echo "<td>" . $row["status_"] . "</td>";
							echo "<td><a href='../student_details.php?id=" . $row["Reg_id"] . "'>Edit</a> | <a href='../student_details.php?id=" . $row["Reg_id"] . "'>Delete</a></td>";
							echo "</tr>";
						}
						echo "</table>";

						// Close MySQL connection
						mysqli_close($conn);

						?>

</div>		
<div class="container">
	<h2 class="heading text-capitalize mb-sm-5 mb-4"> Course Details </h2>						
					<?php
						// Connect to MySQL database
						$servername = "localhost";
						$username = "root";
						$password = "";
						$database = "hostel_management_system";

						// Create connection
						$conn = new mysqli($servername, $username, $password, $database);
						// Check connection
						if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
						}

						// Get data from users table
						$sql = "SELECT * FROM Course";
						$result = mysqli_query($conn, $sql);

						// Display data in a table
						echo "<table border=2>";
						echo "<tr><th>course_ID</th><th>Course name</th><th>no_of_year</th>
						<th>Status</th><th>Action</th></tr>";
						while ($row = mysqli_fetch_assoc($result)) {
							//$sql = "CREATE TABLE Course(course_id int PRIMARY KEY,course_name varchar(50) 
							//NOT NULL,no_of_year int NOT NULL,status_ varchar(50))";

							echo "<tr>";
							echo "<td>" . $row["course_id"] . "</td>";
							echo "<td>" . $row["course_name"] . "</td>";
							echo "<td>" . $row["no_of_year"] . "</td>";
							echo "<td>" . $row["status_"] . "</td>";
							echo "<td><a href='../student_details.php?id=" . $row["course_id"] . "'>Edit</a> | <a href='../student_details.php?id=" . $row["course_id"] . "'>Delete</a></td>";
							echo "</tr>";
						}
						echo "</table>";

						// Close MySQL connection
						mysqli_close($conn);

						?>

</div>	
<div class="container">
	<h2 class="heading text-capitalize mb-sm-5 mb-4"> Room Block Details </h2>						
					<?php
						// Connect to MySQL database
						$servername = "localhost";
						$username = "root";
						$password = "";
						$database = "hostel_management_system";

						// Create connection
						$conn = new mysqli($servername, $username, $password, $database);
						// Check connection
						if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
						}

						// Get data from users table
						$sql = "SELECT * FROM Blocks";
						$result = mysqli_query($conn, $sql);

						// Display data in a table
						echo "<table border=2>";
						echo "<tr><th>Block_ID</th><th>Block name</th><th>Gender</th><th>Description</th>
						<th>Status</th><th>Action</th></tr>";
						while ($row = mysqli_fetch_assoc($result)) {
// 							$sql = "CREATE TABLE Blocks(block_id int primary key, block_name varchar(50), 
//gender varchar(10), description varchar(50), status varchar
// (50) )";
							echo "<tr>";
							echo "<td>" . $row["block_id"] . "</td>";
							echo "<td>" . $row["block_name"] . "</td>";
							echo "<td>" . $row["gender"] . "</td>";
							echo "<td>" . $row["description"] . "</td>";
							echo "<td>" . $row["status"] . "</td>";
							echo "<td><a href='../student_details.php?id=" . $row["block_id"] . "'>Edit</a> | <a href='../student_details.php?id=" . $row["block_id"] . "'>Delete</a></td>";
							echo "</tr>";
						}
						echo "</table>";

						// Close MySQL connection
						mysqli_close($conn);

						?>

</div>	
<br>
<br>
<br>

<!-- footer -->
<footer class="py-5">
	<div class="container py-md-5">
		<div class="footer-logo mb-5 text-center">
			<a class="navbar-brand" href="#" target="_blank">HMS <span class="display"> JAIPUR</span></a>
		</div>
		<div class="footer-grid">
			
			<div class="list-footer">
				<ul class="footer-nav text-center">
					<li>
						<a href="admin_home.php">Home</a>
					</li>
					
					<li>
						<a href="create_hm.php">Appoint</a>
					</li>
					<li>
						<a href="students.php">Students</a>
					</li>
					<li>
						<a href="admin_contact.php">Contact</a>
					</li>
					<li>
						<a href="admin_profile.php">Profile</a>
					</li>
				</ul>
			</div>
			
		</div>
	</div>
</footer>
<!-- footer -->

<!-- js-scripts -->

	<!-- js -->
	<script type="text/javascript" src="../web_home/js/jquery-2.2.3.min.js"></script>
	<script type="text/javascript" src="../web_home/js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap -->
	<!-- //js -->

	<!-- banner js -->
	<script src="web_home/js/snap.svg-min.js"></script>
	<script src="web_home/js/main.js"></script> <!-- Resource jQuery -->
	<!-- //banner js -->

	<!-- flexSlider --><!-- for testimonials -->
	<script defer src="web_home/js/jquery.flexslider.js"></script>
	<script type="text/javascript">
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	</script>
	<!-- //flexSlider --><!-- for testimonials -->

	<!-- start-smoth-scrolling -->
	<script src="web_home/js/SmoothScroll.min.js"></script>
	<script type="text/javascript" src="web_home/js/move-top.js"></script>
	<script type="text/javascript" src="web_home/js/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			$(".scroll").click(function(event){
				event.preventDefault();
				$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
			});
		});
	</script>
	<!-- here stars scrolling icon -->
	<script type="text/javascript">
		$(document).ready(function() {
			/*
				var defaults = {
				containerID: 'toTop', // fading element id
				containerHoverID: 'toTopHover', // fading element hover id
				scrollSpeed: 1200,
				easingType: 'linear'
				};
			*/
			$().UItoTop({ easingType: 'easeOutQuart' });
			});
	</script>
	<!-- //here ends scrolling icon -->
	<!-- start-smoth-scrolling -->

<!-- //js-scripts -->

</body>
</html>
		